# TP1 - Inter Process Communication

## Autores
- [Francisco Bernad](https://github.com/FrBernad)
- [Nicolás Rampoldi](https://github.com/NicolasRampoldi) 


# Compilation

Execute `make` or `make all` commands on your shell to compile all source files.

# Execution
